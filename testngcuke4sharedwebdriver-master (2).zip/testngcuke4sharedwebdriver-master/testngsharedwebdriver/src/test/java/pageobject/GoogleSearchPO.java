package pageobject;

import java.util.ArrayList;
import java.util.List;

import driver.Wrappers;
import org.json.JSONObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;

import driver.DriverFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class GoogleSearchPO extends LoadableComponent<GoogleSearchPO>{
	
	@FindBy(css = "div[class='srg'] a > h3[class='LC20lb']")
	public List<WebElement> searchResult;

	/*********From fields****************/
	public final static String fromHeader = "fromHeading";
	public static final String fromEdit = "summaryFromEdit";
	public static final String fromName = "//*[@id='userNameFROM']";
	public static final String fromCountry = "userCountryFROM";
	public final static String fromUserNameError = "userNameFROMerror";
	public static final String fromAddressline1 = "userAddressFROM";
	public static final String fromAddressline2 = "userAptSuiteFROM";
	public final static String fromUserPostalError = "userPostalFROMerror";
	public static final String fromPostal = "userPostalFROM";
	public static final String fromPostallabel = "userPostalFROMLabel";
	public static final String fromState = "userStateFROM";
	public static final String fromCity = "userCityFROM";
	public static final String fromPhoneNumber = "userPhoneNumberFROM";
	public static final String fromEmail = "userEmailFROM";
	public static final String fromCompany = "userCompanyFROM";
	public static final String fromUpdate = "updateFROM";
	public final static String userStateLabelFROM = "userStateFROMLabel";
	//public final static String fromUserNameError = "userNameFROMerror";
	public final static String userNameFROM = "userNameFROM";
	public final static String fromUserCountryError = "userCountryFROMError";
	public final static String fromUserAddressError = "userAddressFROMerror";
	public final static String userEmailFROM = "userEmailFROM";
	public final static String fromuserEmailError = "userEmailFROMerror";
	public final static String summaryFromEdit = "summaryFromEdit";
	public final static String userNoteFROM = "(//span[contains(text(),' Your contacts will appear once you start typing below.')])[1]";
	public final static String fromUserStateError = "userStateFROMError";
	public final static String fromUserCityError = "userCityFROMerror";
	public final static String userCityDropDownListFrom = "//*[@id='userCityFROMDropdown']/li[1]";
	public final static String userNameDropFromDownList = "//*[@id='userNameFROMDropdown']/li[1]";
	public final static String fromUserPhonenumberError = "userPhoneNumberFROMerror";
	public final static String userFromAltPickupEdit = "summaryFromAltEdit";
	public final static String fromUserAddressLine2Error = "userAptSuiteFROMerror";
	/*********TO fields***************/
	public final static String toHeader = "fx-mags-address-form-to>h3";
	public static final String toName = "//*[@id='field_contact_personName_firstName']";
	public final static String toCompany = "field_contact_companyName";
	public final static String toCountry = "field_address_countryCode";
	public final static String toAddressline1 = "field_address_streetLine1";
	public final static String toAddressline2 = "field_address_streetLine2";
	public final static String toCity = "field_address_city";
	public final static String toState = "field_address_stateOrProvinceCode";
	public final static String toPostal = "field_address_postalCode";
	public final static String toPhoneNumber = "field_contact_phoneNumber";
	public final static String toEmail = "field_notification_0_email";
	public final static String toUpdate = "fx-mags-address-form+div .fdx-c-button--primary";
	public static final String toUserError = "toUserNameError";
	public static final String globalLoginDropDown = "HeaderLogin";
	public final static String toUserPostalError = "errors_address_postalCode";
	public final static String userPostalTO = "field_address_postalCode";
	public final static String userEmailTO= "field_notification_0_email";
	public final static String userCityTO = "field_address_city";
	public final static String userStateTO = "field_address_stateOrProvinceCode";
	public final static String userPhoneNumberTO = "field_contact_phoneNumber";
	public final static String userCountryTO = "field_address_countryCode";
	public final static String addressSubmitTO = "fx-mags-address-form+div button";
	public final static String userCompanyTO = "field_contact_companyName";
	public final static String userNameTO = "field_contact_personName_firstName";
	public final static String userAddressBookTO= "[fxmagsmodal=addressBook]";
	public final static String userAddressBookCloseTO= "#e2e-addressBook-close > svg";
	public final static String userAddressBookSearchQueryTO= "field_address_book_search_query";






	public final static String alternativePickupAdressLine2 = "alternativePickupAptSuite";
	public final static String userCompanyError = "userCompanyFROMerror";
	public final static String alternativePickupPostal = "alternativePickupPostal";
	public final static String alternativePickupAdressLine2Error = "alternativePickupAptSuiteerror";

	@FindBy(id = fromHeader)
	public static WebElement fromfieldHeader;

	@FindBy(id = fromEdit)
	public static WebElement fromfieldEdit;

	@FindBy(id = summaryFromEdit)
	public static WebElement summaryFromedit;

	@FindBy(id = globalLoginDropDown)
	public static WebElement globalLoginDropDowns;

	@FindBy(id =userEmailFROM)
	public static WebElement userEmailfROM;

	@FindBy(id = fromUserNameError)
	public static WebElement fromUserNameerror;

	@FindBy(id = fromuserEmailError)
	public static WebElement fromuserEmailerror;

	@FindBy(xpath = fromName)
	public static WebElement fromfieldName;

	@FindBy(id = fromCountry)
	public static WebElement fromfieldCountry;

	@FindBy(id = fromAddressline1)
	public static WebElement fromfieldAddress1;

	@FindBy(id = fromAddressline2)
	public static WebElement fromfieldAddress2;

	@FindBy(id = fromPostal)
	public static WebElement fromfieldPostal;

	@FindBy(id = fromPostallabel)
	public static WebElement fromfieldPostalLabel;

	@FindBy(id = fromState)
	public static WebElement fromfieldState;

	@FindBy(id = fromCity)
	public static WebElement fromfieldCity;

	@FindBy(id = fromPhoneNumber)
	public static WebElement fromfieldPhnNum;

	@FindBy(id = fromEmail)
	public static WebElement fromfieldEmail;

	@FindBy(id = fromCompany)
	public static WebElement fromfieldCompany;

	@FindBy(id = fromUpdate)
	public static WebElement fromfieldUpdate;

	@FindBy(xpath = toUserError)
	public static WebElement toErrorMsg;

	@FindBy(css = toHeader)
	public static WebElement tofieldHeader;

	@FindBy(xpath = toName)
	public static WebElement tofieldName;

	@FindBy(id = toCompany)
	public static WebElement tofieldCompany;

	@FindBy(id = toCountry)
	public static WebElement tofieldCountry;

	@FindBy(id = toAddressline1)
	public static WebElement tofieldAddress1;

	@FindBy(id = toAddressline2)
	public static WebElement tofieldAddress2;

	@FindBy(id = toPostal)
	public static WebElement tofieldPostal;

	@FindBy(id = toState)
	public static WebElement tofieldState;

	@FindBy(id = toCity)
	public static WebElement tofieldCity;

	@FindBy(id = toPhoneNumber)
	public static WebElement tofieldPhnNum;

	@FindBy(id = toEmail)
	public static WebElement tofieldEmail;

	@FindBy(css = toUpdate)
	public static WebElement tofieldUpdate;

	@FindBy(xpath = userNoteFROM)
	public static WebElement userNotefROM;

	@FindBy(id = toUserPostalError)
	public static WebElement toUserPostalerror;


	@FindBy(id = userNameFROM)
	public static WebElement userNamefROM;

	@FindBy(id = fromUserCountryError)
	public static WebElement fromUserCountryerror;

	@FindBy(id = fromUserAddressError)
	public static WebElement fromUserAddresserror;

	@FindBy(id = fromUserPostalError)
	public static WebElement fromUserPostalerror;

	@FindBy(id =userStateLabelFROM)
	public static WebElement userStateLabelfROM;

	@FindBy(id = fromUserStateError)
	public static WebElement fromUserStateerror;

	@FindBy(id = fromUserCityError)
	public static WebElement fromUserCityerror;

	@FindBy(xpath = userCityDropDownListFrom)
	public static List<WebElement> userCityDropDownListfrom;

	@FindBy(xpath = userNameDropFromDownList)
	public static List<WebElement> userNameDropFromDownlist;

	@FindBy(id = fromUserPhonenumberError)
	public static WebElement fromUserPhonenumbererror;

	@FindBy(id = userFromAltPickupEdit)
	public static WebElement userFromAltPickupedit;

	@FindBy(id =alternativePickupAdressLine2)
	public static WebElement alternativePickupAdressline2;

	@FindBy(id = fromUserAddressLine2Error)
	public static WebElement fromUserAddressLine2error;

	@FindBy(id = userCompanyError)
	public static WebElement userCompanyerror;

	@FindBy(id = alternativePickupPostal)
	public static WebElement alternativePickuppostal;

	@FindBy(id = alternativePickupAdressLine2Error)
	public static WebElement alternativePickupAdressLine2error;

	@FindBy(id = userPostalTO)
	public static WebElement userPostaltO;

	@FindBy(id =userCityTO)
	public static WebElement userCitytO;

	@FindBy(id =userStateTO)
	public static WebElement userStatetO;

	@FindBy(id = userPhoneNumberTO)
	public static WebElement userPhoneNumbertO;

	@FindBy(id = userEmailTO)
	public static WebElement userEmailtO;

	@FindBy(id = userCountryTO)
	public static WebElement userCountrytO;

	@FindBy(css = addressSubmitTO)
	public static WebElement addressSubmittO;

	@FindBy(id = userCompanyTO)
	public static WebElement userCompanytO;

	@FindBy(id = userNameTO)
	public static WebElement userNametO;

	@FindBy(css= userAddressBookTO)
	public static WebElement userAddressBooktO;

	@FindBy(css= userAddressBookCloseTO)
	public static WebElement userAddressBookClosetO;

	@FindBy(id= userAddressBookSearchQueryTO)
	public static WebElement userAddressBookSearchQuerytO;
	
	public GoogleSearchPO() {
		PageFactory.initElements(DriverFactory.getDriver(), this);
	}
	
	public int searchResultCount() {

		return searchResult.size() + 1;
	}

	public void clickOnFromEdit() throws InterruptedException {
		Wrappers.waitForElement(fromfieldEdit);
		Wrappers.scrollToElement(fromfieldEdit);
		Wrappers.clickOnElement(fromfieldEdit);
		Thread.sleep(3000);
	}

	public void verifyFromSection(){

		try{
			Thread.sleep(5000);
			JSONObject users = Wrappers.getUserAddressDetailsJson("Bindu  TM");
			Wrappers.getTextFromAndCompareTextWith(userNamefROM,users.get("Name").toString());
			Wrappers.getTextFromAndCompareTextWith(fromfieldCountry,users.get("country").toString());
			Wrappers.getTextFromAndCompareTextWith(fromfieldAddress1,users.get("address").toString());
			//Wrappers.getTextFromAndCompareTextWith(driver,gsPO.fromfieldAddress2,users.get("aptsuite").toString());
			Wrappers.getTextFromAndCompareTextWith(fromfieldPostal,users.get("postal").toString());
			Wrappers.getTextFromAndCompareTextWith(fromfieldState,users.get("state").toString());
			Wrappers.getTextFromAndCompareTextWith(fromfieldCity,users.get("city").toString());
			Wrappers.getTextFromAndCompareTextWith(fromfieldPhnNum,users.get("phonenumber").toString());
			Wrappers.getTextFromAndCompareTextWith(fromfieldEmail,users.get("email").toString());

		} catch (Exception e) {
			System.out.println(e.getMessage());
			Assert.fail();
		}
	}

	public void enterValidationUserEmail(List<String> valueToEnter){
		ArrayList<String> values = new ArrayList<>(valueToEnter);
		for (String val : values) {
			try {
				//   waitForElement(inputElement);
				userEmailfROM.clear();
				Wrappers.enterValue(userEmailfROM, val);
				Wrappers.tabOut(userEmailfROM);
				Wrappers.getTextFromAndCompareTextWithUI(fromuserEmailerror, Wrappers.getEmailValidationError("validationErrorSection.email", "pattern"));
			} catch (Exception e) {
				Assert.fail();
			}

		}
	}

	public void fromSubmit() throws InterruptedException {
		Wrappers.clickOnElement(fromfieldUpdate);
	}

	public void verifyElement(List<String> classPath){
		try {
			for (String s : classPath) {
				WebElement element = Wrappers.getWebElementByClassPath(s);
				//     waitForElement(element);
				if (element.isDisplayed()) {
					System.out.println("Element is displayed");
				} else{
					Assert.fail();
					System.out.println("Element is not displayed");
				}
			}
		} catch (Exception e) {
			Assert.fail();
		}
	}

	public void verifyActiveEleme(String elementToVerifyClassPath, String attribute){
		boolean matched = false;
		try {
			WebElement activeElement = DriverFactory.getDriver().switchTo().activeElement();
			String activeElementAttribute = activeElement.getAttribute(attribute);
			String expectedElementAttribute = Wrappers.getWebElementByClassPath(elementToVerifyClassPath).getAttribute(attribute);
			if (activeElementAttribute.equals(expectedElementAttribute)) {
				matched = true;
				System.out.println(matched);
			} else {
				Assert.fail();
			}
		} catch (Exception e) {
			Assert.fail();
		}
	}

	@Override
	protected void load() {
	}

	@Override
	protected void isLoaded() throws Error {
		
	}
}
